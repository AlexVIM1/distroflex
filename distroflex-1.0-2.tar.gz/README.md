# DistroFlex
Cross-distro settings tool

# Use
* Set your distro settings as you need
* Check system parameters and indicators
* Interaction with hardware
* All in one place

# Customize
* Make plugins with API (will be released a little later)
* Root included

# Get as package
* Binary files in branch pkg [Go](https://github.com/AlexVIM1/distroflex/tree/pkg) [Download](https://raw.githubusercontent.com/AlexVIM1/distroflex/pkg/distroflex-1.0-1-x86_64.tar.gz) 
* Arch Linux [Get](https://aur.archlinux.org/packages/distroflex)
* DEB (soon)
* RPM (soon)
* FlatPak (soon)
